var train={no:"",na:"",so:"",de:"",fa:""};
pa ="<table align=center><tr><th>Sl no</th><th>NAME</th><th>Age</th><th>Gender</th><th>Fare</th></tr>";
var date;
var pacd;
var tt_fa=0;
var p_c=0;
var PNR="";
var count=100;
var ticketdata="";
var d_tp="\nSl.no\t Name\t\t\t\t\tAge\tGender\tFare\n";
var d_tt="";   
 var ticket="";  
   
   
   
   
   

////////////////////////////////////////////////////////////////////////////////////////////////
 //users


        function sign_in(){
            console.log("sign in");

                userid=document.getElementById("uid").value;
                userp=document.getElementById("pswd").value;
                url="http://localhost:8080/user/get_user_by_uid/"+userid;


                let fr=fetch(url,{method: 'GET'})
                fr.then(function (response) {
                return response.json();
            })
            .then(data => {
                console.log("success")
                append(data);    
            })
            .catch(function (err) {
            console.log('error: ' + err);
            alert("invalid User ID");
            });




            function append(data) 
                {
                    if (userid==data.usid && userp==data.paswd) 
                    {
                        console.log("user login sucessfull");
                        alert("login sucessful")
                        window.location.replace("train_disp.html");
                    }
                    else {
                    alert("invalid password");
                    }
                
                
                }


        }

     //-----------------------------------------------------------------------------------


            function sign_up(){

                console.log("sign up");
                var nam = document.getElementById("sfn").value;
                var dob = document.getElementById("sdob").value;
                var dobi=dob.toString();
                var us = document.getElementById("suid").value;
                var ps = document.getElementById("spswd").value;
                

                var data = {
                    "name":nam,
                "dob":dobi,
                "usid":us,
                "paswd":ps
                }
            


                let options = {
                    method:'POST',
                    headers:{
                        'Content-Type':'application/json'
                    },
                    body:JSON.stringify(data)
                }
            

                let fres = fetch("http://localhost:8080/user/save",options);
                fres.then(res => res.json()).then(d => {
                    console.log("success"+ d);
                   
                    alert("registered sucessfully");
                })
            }



    //-------------------------------------------------------------------------------------------------

            function get_user() 
            {
                console.log("get user");

                let fres = fetch("http://localhost:8080/user/get_all_user");
                fres.then(function (response) {
                        return response.json();
                    })
                    .then(function (data) {
                        appendData(data);
                    })
                    .catch(function (err) {
                        console.log('error: ' + err);
                    });

                    
                function appendData(data) {
                    
                    table="<table align=center><tr><th>User ID</th><th>NAME</th><th>DOB</th></tr>";
                    for (var i = 0; i < data.length; i++) {
                        table+="<tr><td>"+data[i].usid+"</td><td>"+data[i].name+"</td><td>"+data[i].dob+"</td></tr>";

                    }
                    table+="</table>"
                
                    document.getElementById("userdata").innerHTML=table;
                    
                }      
            
            }


         //----------------------------------------------------------------------------------------------           

            function del_user()
            {


                console.log(" delete user");

                var tr=document.getElementById("u_dlt").value;
                let url="http://localhost:8080/user/delete_id/"+tr;

                let fr= fetch(url,{method: 'DELETE'})
                .then(function (d) {
                    console.log("success"+ d)
                    alert("User deleted sucessfully");
                   
                })
                .catch(function (err) {
                    console.log('error: ' + err);
                    alert("invalid User ID");
                });

            }


///////////////////////////////////////////////////////////////////////////////////////////////////.

//Admin user

            function sign_inA() {

                console.log("sign in admin");

                var ua=document.getElementById("uid").value ;
              var pa=document.getElementById("pswd").value ;
               
               
            
                
                if(ua=="admin" && pa=="a@123")
                {
                    var url="admin.html"
                window.location.replace(url);
              
                console.log("admin login");
                }else
                {
                    alert("Invalid data XXX")
                }
            }


///////////////////////////////////////////////////////////////////////////////////////////////////.
    
//Trains

            function add_train(){

                console.log("add train");
                var t_no = document.getElementById("tr_no").value;
                var t_name= document.getElementById("tr_na").value;
                var t_source= document.getElementById("tr_so").value;
                var t_desti= document.getElementById("tr_de").value;
                var t_fare= document.getElementById("tr_fa").value;
            

                var data =
                    {

                        "trainNo": parseInt(t_no),
                        "trainName": t_name,
                        "source": t_source,
                        "destination": t_desti,
                        "fare": parseInt(t_fare)
                    
                    }

                let options = {
                    method:'POST',
                    headers:{
                        'Content-Type':'application/json'
                    },
                    body:JSON.stringify(data)
                }

                let fres = fetch("http://localhost:8080/train/save_train",options);
                fres.then(res => res.json()).then(d => {
                    console.log("success"+ d);
                    alert("Train added sucessfully");
                    
                })
            }


    //-------------------------------------------------------------------------------------------------


            function show_trains(){

                console.log("Show trains");
                    let fres = fetch("http://localhost:8080/train/get_all_trains");
                    fres.then(function (response) {
                            return response.json();
                        })
                        .then(function (data) {
                            appendData(data);
                        })
                        .catch(function (err) {
                            console.log('error: ' + err);
                        });

                        
                    function appendData(data) {
                        
                        table="<table align=center><tr><th>TRAIN_NO</th><th>TRAIN_NAME</th><th>SOURCE</th><th>DESTINATION</th><th>TICKET_PRICE</th></tr>";
                        for (var i = 0; i < data.length; i++) {
                            table+="<tr><td>"+data[i].trainNo+"</td><td>"+data[i].trainName+"</td><td>"+data[i].source+"</td><td>"+data[i].destination+"</td><td>"+data[i].fare+"</td></tr>";

                        }
                        table+="</table>"
                    
                        document.getElementById("traindata").innerHTML=table;
                        
                    }         
            }


    //-------------------------------------------------------------------------------------------------


            function delete_train(){

                console.log("delete train");
                var tr=document.getElementById("tr_dlt").value;
                let url="http://localhost:8080/train/delete_trainNo/"+tr;

                let fr= fetch(url,{method: 'DELETE'})
                .then(function (d) {
                    console.log("success"+ d)
                    alert("Train deleted sucessfully");
                   
                })

            }

    
    //-------------------------------------------------------------------------------------------------

 
            function get_train()
            {
                console.log("get train");
                var tr=document.getElementById("tr_no").value;
                    date=document.getElementById("da_te").value;
                console.log(date);
                if (date=="") {
                    alert("Choose Travel date")
                }
                else{
            
                console.log(tr)
                
            
            
                
                let url="http://localhost:8080/train/get_train_by_no/"+tr;
            
                    let fr=fetch(url,{method: 'GET'})
                    fr.then(function (response) {
                    return response.json();
                })
                .then(data => {
                    console.log("success")
                    append(data);    
                })


                }


                function append(data) {
                        
                    train.no=data.trainNo;
                    train.na=data.trainName;
                    train.so=data.source;
                    train.de=data.destination;
                    train.fa=data.fare;
                
                    console.log(train);
                    
                            table="<table align=center><tr><th>TRAIN_NO</th><th>TRAIN_NAME</th><th>SOURCE</th><th>DESTINATION</th></tr>";
                            
                                table+="<tr><td>"+data.trainNo+"</td><td>"+data.trainName+"</td><td>"+data.source+"</td><td>"+data.destination+"</td><</tr>";
                            table+="</table>"
                          
                            document.getElementById("trdata").innerHTML=table;
            
                }  
                
            }


///////////////////////////////////////////////////////////////////////////////////////////////////.



    
    
    //-------------------------------------------------------------------------------------------------

                var pd_tt="Sl.no &ensp; Name &emsp;&emsp; &emsp;&emsp; Age &emsp; Gender &emsp; Fare"


                function add_pa() 
                {
                    console.log("add passenger");

                  if (train.no=="") {
                        alert("Choose Train");
                    }
                    else
                    { 
                        tab="<table align=center id='pa_t'><tr><th>Sl no</th><th>NAME</th><th>Age</th><th>Gender</th><th>Fare</th></tr>";
                            var pac=document.getElementById("pa_no").value;
                            var p_fa=train.fa;
                            pacd=parseInt(pac);
                            if (pacd>p_c) {
                                p_c++;
                                p_na=document.getElementById("pa_na").value.toUpperCase();
                                var p_nas=p_na;
                                var l=p_na.length;
                                console.log(l);
                                
                                for (let index = 0; index < 8-l; index++) {
                                p_nas+="&nbsp;";   
                                }
                                p_ag=parseInt(document.getElementById("pa_ag").value);
                                p_gn=((document.getElementById("pa_gn").value).toUpperCase()).charAt(0);
                                
                                if (p_ag<=12) {
                                    p_fa=p_fa*50/100; 
                                }else if (p_ag>60) {
                                    p_fa=p_fa*60/100;
                                }

                                if (p_gn=='F') {
                                    p_fa=p_fa*75/100;
                                    
                                }

                                d_tp+= p_c +"\t"+p_na+"\t\t\t\t\t"+p_ag+"\t"+p_gn+"\t"+p_fa+"\n";
                                tt_fa +=p_fa;
                                tab+="<tr> <td>"+ p_c +"</td><<td>"+p_na+"</td><td>"+p_ag +"</td><td>"+p_gn+"</td> <td>"+p_fa+"</td></tr>";
                                pa+="<tr> <td>"+ p_c +"</td><<td>"+p_na+"</td><td>"+p_ag +"</td><td>"+p_gn+"</td> <td>"+p_fa+"</td></tr>";
                                tab+="</table>"
                                pd_tt+="<br>"+p_c+" &emsp; &emsp;"+p_nas+" &emsp; &emsp; "+p_ag+" &emsp; &emsp;"+p_gn+" &emsp; &ensp; &emsp;"+p_fa;
                                   
                                if (p_c==pacd) {
                                  
                                    show_pa();
                                    }
                                    else{
                                    document.getElementById("padata").innerHTML=tab;
                                    }


                                

                                    
                            }
                            else{
                                alert(pacd +" passengers added sucessfully");
                                
                            }
                    }
                }

    
    
    //-------------------------------------------------------------------------------------------------


                function show_pa() {
                    console.log("show passenger");
                    tab+="</table>"
                                document.getElementById("padata").innerHTML=pa;
                }

    
    
    //-------------------------------------------------------------------------------------------------



                function book_ticket() 
                {
                    console.log("book ticket");

                        if (p_c==pacd) {
                            PNR=get_pnr();
                           

                        } 
                        else{
                            alert("add passenger")
                        }

                
                }
                function add_data_tt() {
                   
                    d_tt+="Train Number\t\t:"+train.no+"\n";
                    d_tt+="Train Name\t\t:"+train.na+"\n";
                    d_tt+="From\t\t\t:"+train.so+"\n";
                    d_tt+="To\t\t\t:"+train.de+"\n";
                    d_tt+="\n"+d_tp+"\n";
                    d_tt+="\n\tTotal Fare : "+tt_fa+"\n";

                }
    
    
    //-------------------------------------------------------------------------------------------------



                function get_pnr() 
                {

                    console.log("Get pnr");
                    var pnr=train.so.charAt(0);
                    pnr+=train.de.charAt(0);
                    pnr+=date;
                    pnr+=150;

                        ticket="PNR : "+pnr+"<br>"
                        ticket+="Tran Number : "+train.no+"<br>Train Name : "+train.na+"<br>From : "+train.so+"<br>To : "+train.de+"<br>Date : "+date;
                        ticket+="<br>"+pd_tt;
                        ticket+="<br> <br> Total Fare = "+tt_fa;
                           
                            add_data_tt();
                        document.getElementById("tf").innerHTML=tt_fa;

                           
                            PNR=pnr;
                            console.log(PNR);
                         
                            return pnr;
                `   `}

            
    
    
    //-------------------------------------------------------------------------------------------------


                function download_ticket()
                { 
                    console.log("download ticket");
                    
                    if (PNR=="") {
                        alert("No Dta found");
                    }
                    else
                    {
                            download(PNR,d_tt);

                          var url="train_disp.html"
                window.location.replace(url);
                    }
                }


    
    
    //-------------------------------------------------------------------------------------------------


                function download(filename, text1) {
                    console.log("download");
                    var text="PNR\t\t\t:"+PNR+"\n"+text1;

                    var element = document.createElement('a');
                    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
                    element.setAttribute('download', filename+".txt");
                
                    element.style.display = 'none';
                    document.body.appendChild(element);
                
                    element.click();
                
                    document.body.removeChild(element);
                }

    
    
    //-------------------------------------------------------------------------------------------------
///////////////////////////////////////////////////////////////////////////////////////////////////////


                function pym()
                {
                    if (PNR=="") {
                        alert("No Dta found");
                    }
                    else
                    {
                      
                    alert("Payement successful")
                    console.log(ticket)
                    document.getElementById("tcdata").innerHTML=ticket;
                    }

                }
//-------------------------------------------------------------------------------------------------
                
                    
                  