package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RRsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(RRsystemApplication.class, args);
	}

}
