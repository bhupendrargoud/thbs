package com.example.demo.model;

import java.util.Date;
import java.util.Iterator;
import java.util.TreeSet;



public class B_ticket {
	

	
	
	static private String PNR;
	static private Date date;
	static private double Fare;
	
	
	static private Train train;
	
	static private String B_t;
	
	static TreeSet<String> pass=new TreeSet<String>();
	
	
	
	
	public B_ticket() {
		
	}

	public void addPassenger(Passenger pa)
	{
		
		pass.add(pa.getpName()+"\t\t"+pa.getpAge()+"\t\t"+pa.getpGender()+"\t\t"+pa.getpFare());
	}
	
	public void addTrain(Train t) {
		train=t;
	}
	
	public void addTc(String pnr,Date dt,double fare)
	{
		PNR=pnr;
		date=dt;
		Fare=fare;
	}
	
	
	
	
	
	
	public String writeTicket()
	{
		
			
			int c=0;
			
			B_t=("PNR \t\t: "+PNR+"\n");
			B_t+=("Train no\t:"+train.getTrainNo()+"\n");
			B_t+=("Train name\t:"+train.getTrainName()+"\n");
			B_t+=("From\t\t:"+train.getSource()+"\n");
			B_t+=("To\t\t:"+train.getDestination()+"\n");
			B_t+=("Date\t\t:"+date+"\n");
			B_t+=("\n"+"======================================================================");
			
			B_t+=("\nPassengers"+"\n");
			B_t+=("Sl.no\tName\t\t Age\t\t Gender\t\t Fare"+"\n");
			
			Iterator it =pass.iterator();
			while(it.hasNext())
			{	c++;
				String s=(String) it.next();
				B_t+=(c+"\t"+s+"\n");
			}
			
			B_t+=("\n"+"======================================================================");
			B_t+=("\nTotal Fare : Rs "+Fare);
			
			
			
			System.out.println("Ticket generated");
		return B_t;
		
		
	}

}
