package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="passenger") 
public class Passenger {
		
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Id
		private int pId;
	
	@Column(name="pName")
		private String pName;
	
	@Column(name="pAge")
		private int pAge;
	
	@Column(name="pGender")
		private char pGender;
	
	@Column(name="pFare")
	private int pFare;
	
	
	
	
	

	public Passenger() {
		
	}

	
	



	


	public Passenger(int pId, String pName, int pAge, char pGender, int pFare) {
		super();
		this.pId = pId;
		this.pName = pName;
		this.pAge = pAge;
		this.pGender = pGender;
		this.pFare = pFare;
	}









	public int getpFare() {
		return pFare;
	}









	public void setpFare(int pFare) {
		this.pFare = pFare;
	}









	public int getpId() {
		return pId;
	}




	public void setpId(int pId) {
		this.pId = pId;
	}




	public String getpName() {
		return pName;
	}




	public void setpName(String pName) {
		this.pName = pName;
	}




	public int getpAge() {
		return pAge;
	}




	public void setpAge(int pAge) {
		this.pAge = pAge;
	}




	public char getpGender() {
		return pGender;
	}




	public void setpGender(char pGender) {
		this.pGender = pGender;
	}




	@Override
	public String toString() {
		return "Passenger [pId="+ pId +", pName=" + pName + ", pAge =" + pAge + ", pGender=" + pGender +", pFare=" + pFare + "]";
		
	}




		
		
	
	

}
