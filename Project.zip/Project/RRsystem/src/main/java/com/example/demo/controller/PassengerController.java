package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.B_ticket;
import com.example.demo.model.Passenger;

import com.example.demo.repository.PassengerRepository;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/passenger")

public class PassengerController {

	@Autowired
	PassengerRepository passengerRepository;
	
	
	//get passenger by id
	@GetMapping("/get_passenger_by_id/{p_id}")
	public ResponseEntity<Passenger> getPassengerById(@PathVariable("p_id") int p_id)
	{
		Optional<Passenger> passengerData=passengerRepository.findById(p_id);
		
		
		if(passengerData.isPresent())
		{
			return new ResponseEntity<>(passengerData.get(),HttpStatus.OK);
		}
		else
		{
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	//save passenger
	@PostMapping("/save_passenger") 
	public ResponseEntity<Passenger> createPassenger(@RequestBody Passenger passenger){
		Passenger _passenger = passengerRepository.save(new Passenger(passenger.getpId(),passenger.getpName(),passenger.getpAge(),passenger.getpGender(),passenger.getpFare()));		
		B_ticket bc= new B_ticket();
		bc.addPassenger(_passenger);
		return new ResponseEntity<>(_passenger,HttpStatus.CREATED);
	}
	
	//fetch all passengers
		@GetMapping("/get_all_passengers")
		public ResponseEntity<List<Passenger>> getAllTrains(){
			List passenger=new ArrayList<Passenger>();
			passengerRepository.findAll().forEach(passenger::add);
			return new ResponseEntity<>(passenger,HttpStatus.OK);
		}
		
		//update passenger by id
				@PutMapping("/update_passenger/{id")
				public ResponseEntity<Passenger> updatePassenger(@PathVariable("id") int id,@RequestBody Passenger passenger)
				{
					Optional<Passenger> passengerData=passengerRepository.findById(id);
					if(passengerData.isPresent())
					{
						Passenger _passenger=passengerData.get();
						_passenger.setpId(passenger.getpId());
						_passenger.setpName(passenger.getpName());
						_passenger.setpAge(passenger.getpAge());
						_passenger.setpGender(passenger.getpGender());
						return new ResponseEntity<>(passengerData.get(),HttpStatus.OK);
					}
					else
					{
						return new ResponseEntity<>(HttpStatus.NOT_FOUND);
					}
					
				}
				
				//delete by passenger id
				@DeleteMapping("/delete_passengerId/{id}")
				public ResponseEntity<HttpStatus> deletePassenger(@PathVariable("id") int id)
				{
					passengerRepository.deleteById(id);
					return new ResponseEntity<>(HttpStatus.NO_CONTENT);
				}
	
}
