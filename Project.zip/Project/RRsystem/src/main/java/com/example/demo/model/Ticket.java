package com.example.demo.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="ticket") 
public class Ticket {
	
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Id
	private int id;
	
	@Column(name="PNR")
	private String PNR;
	
	@Column(name="train")
	private int train;
	
	@Column(name="date")
	private Date date;
	
	@Column(name="fare")
	private double fare;
	
	
	

	public Ticket() {
		// TODO Auto-generated constructor stub
	}




	public Ticket(String pNR, int train, Date date, double fare) {
		super();
		this.PNR = pNR;
		this.train = train;
		this.date = date;
		this.fare = fare;
	}




	public String getPNR() {
		
		return PNR;
	}




	public void setPNR(String pNR) {
		this.PNR = pNR;
	}




	public int getTrain() {
		return train;
	}




	public void setTrain(int train) {
		this.train = train;
	}




	public Date getDate() {
		return date;
	}




	public void setDate(Date date) {
		this.date = date;
	}




	public double getFare() {
		return fare;
	}




	public void setFare(double fare) {
		this.fare = fare;
	}
	
	

	public int getId() {
		return id;
	}




	public void setId(int id) {
		this.id = id;
	}




	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Ticket [PNR=" + PNR + ", train=" + train + ", date=" + date+ ", fare=" + fare+"]";
	}
	
	
	
	

}
