package com.example.demo.model;



import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="User") 
public class User {
	
	
	@Id
	private String usid;
	
	@Column(name="name")
	 private String name;
	 
	@Column(name="dob")
	 private String dob;
	
	 
	@Column(name="paswd")
	 private String paswd;
	 
	 
	 
	 

	public User() {
		
	}

	public User( String name, String dob, String usid, String paswd) {
		super();
		this.name = name;
		this.dob = dob;
		this.usid = usid;
		this.paswd = paswd;
	}

	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getUsid() {
		return usid;
	}

	public void setUsid(String usid) {
		this.usid = usid;
	}

	public String getPaswd() {
		return paswd;
	}

	public void setPaswd(String paswd) {
		this.paswd = paswd;
	}

	@Override
	public String toString() {
		
		return "User [ name=" + name + ", dob=" + dob + ", usid=" + usid + ", paswd="+ paswd +"]";
	}
	 
	 
	
	 
}
