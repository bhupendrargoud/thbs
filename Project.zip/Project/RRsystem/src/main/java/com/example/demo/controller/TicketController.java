package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.B_ticket;
import com.example.demo.model.Ticket;

import com.example.demo.repository.TicketRepository;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/ticket")
public class TicketController {
	
	@Autowired
	TicketRepository ticketRepository;
	
	B_ticket bc= new B_ticket();
	
	
	
	
	//to get specific ticket by id
		@GetMapping("/get_ticket_by_id/{pnr}")
		public ResponseEntity<Ticket> getTicketByPNR(@PathVariable("pnr") int pnr)
		{
			Optional<Ticket> ticketData=ticketRepository.findById(pnr);
			
			
			if(ticketData.isPresent())
			{
				return new ResponseEntity<>(ticketData.get(),HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		}
		
		
		//to save a ticket
		@PostMapping("/save_ticket") 
		public ResponseEntity<Ticket> createTicket(@RequestBody Ticket ticket){
			Ticket _ticket = ticketRepository.save(new Ticket(ticket.getPNR(),ticket.getTrain(),ticket.getDate(),ticket.getFare()))	;	
			System.out.println(_ticket.getPNR());
			bc.addTc(_ticket.getPNR(), _ticket.getDate(), _ticket.getFare());
			
			return new ResponseEntity<>(_ticket,HttpStatus.CREATED);
		}
		
		//fetch all ticket
				@GetMapping("/get_all_ticket")
				public ResponseEntity<List<Ticket>> getAllTicket(){
					List tickets=new ArrayList<Ticket>();
					ticketRepository.findAll().forEach(tickets::add);
					return new ResponseEntity<>(tickets,HttpStatus.OK);
				}
				
				
						
						//delete ticket by id  number
						@DeleteMapping("/delete_ticketID/{id}")
						public ResponseEntity<HttpStatus> deleteTrain(@PathVariable("num") int num)
						{
							ticketRepository.deleteById(num);
							return new ResponseEntity<>(HttpStatus.NO_CONTENT);
						}
						
						//update ticket by id
						@PutMapping("/update_ticketid/{num}")
						public ResponseEntity<Ticket> updateTicket(@PathVariable("num") int num,@RequestBody Ticket ticket)
						{
							Optional<Ticket> ticketData=ticketRepository.findById(num);
							if(ticketData.isPresent())
							{
								Ticket _ticket=ticketData.get();
								_ticket.setId(ticket.getId());
								_ticket.setPNR(ticket.getPNR());
								_ticket.setDate(ticket.getDate());
								_ticket.setTrain(ticket.getTrain());
								_ticket.setFare(ticket.getFare());
								
								return new ResponseEntity<>(ticketData.get(),HttpStatus.OK);
							}
							else
							{
								return new ResponseEntity<>(HttpStatus.NOT_FOUND);
							}
							
						}
						
						// return ticket 
						
						@GetMapping("/return_ticket")
						public ResponseEntity<String> getTicket(){
							
							return new ResponseEntity<>(bc.writeTicket(),HttpStatus.OK);
						}
}
